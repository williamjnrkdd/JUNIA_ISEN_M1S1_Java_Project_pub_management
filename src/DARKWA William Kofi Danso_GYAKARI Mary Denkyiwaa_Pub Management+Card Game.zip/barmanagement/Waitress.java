package barmanagement;

/**
 *This class represents a waitress in the bar.
 * @author Mary Denkyiwaa GYAKARI
 */
public class Waitress extends Server {
    
     public Waitress(String firstName, String nickName, int wallet, int popularityRating, String meaningfulCry) {
        super(firstName, nickName, meaningfulCry);
         
        
     }
}

