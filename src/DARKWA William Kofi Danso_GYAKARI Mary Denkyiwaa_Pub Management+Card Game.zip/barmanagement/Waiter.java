package barmanagement;

/**
 *This class represents a waiter in the bar.
 * @author Mary Denkyiwaa GYAKARI
 */
public class Waiter extends Server {
    
    public Waiter(String firstName, String nickName, int wallet, int popularityRating, String meaningfulCry) {
        super(firstName, nickName, meaningfulCry);
    }
}
