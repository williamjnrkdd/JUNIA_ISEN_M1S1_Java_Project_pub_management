package barmanagement;

/**
 *This class represents the fund/ cash register in the bar.
 * @author William Kofi Danso DARKWA
 */
public final class Fund {
    public static int amount = 0;

    public static void setAmount(int amount) {
        Fund.amount += amount;
    }
    
    
}
