package barmanagement;

/**
 *This interface provides the method for starting the Belote Game.
 * @author Will
 */
public interface StartGame {
    public void startGame();
}
